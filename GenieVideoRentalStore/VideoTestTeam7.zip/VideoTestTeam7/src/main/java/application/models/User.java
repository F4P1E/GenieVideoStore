package application.models;

public class User extends Person{

    public User(String name, String lastName, Credentials credentials) {
        super(name, lastName, credentials);
    }

}

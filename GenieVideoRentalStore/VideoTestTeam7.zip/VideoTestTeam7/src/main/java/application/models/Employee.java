package application.models;

public class Employee extends Person{

    public Employee(String name, String lastName, Credentials credentials) {
        super(name, lastName, credentials);
    }
}

package application.models;

public class Administrator extends Person{

    public Administrator(String name, String lastName, Credentials credentials) {
        super(name, lastName, credentials);
    }

}

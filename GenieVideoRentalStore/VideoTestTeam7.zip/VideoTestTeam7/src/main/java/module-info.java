module application.videotest {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;
    requires javafx.graphics;
    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;

    opens application to javafx.fxml;
    exports application;
    exports application.managers;
    opens application.managers to javafx.fxml;
    exports application.models;
    opens application.models to javafx.fxml;
    exports application.controllers;
    opens application.controllers to javafx.fxml;
}